# Architecture - Bedrock Version

## Overview

The Bedrock version replaces CrewAI's framework with direct AWS Bedrock API calls while maintaining the same multi-agent workflow.

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      User Profile Input                      │
│  (Transportation, Diet, Energy Usage, Goals)                 │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                   Orchestrator (Sequential)                  │
└────────────────────────┬────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┬─────────────┐
        │                │                │             │
        ▼                ▼                ▼             ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│   Agent 1    │ │   Agent 2    │ │   Agent 3    │ │   Agent 4    │
│  Knowledge   │ │   Carbon     │ │    Habit     │ │Recommendation│
│   Expert     │ │  Analyzer    │ │    Coach     │ │   Engine     │
└──────┬───────┘ └──────┬───────┘ └──────┬───────┘ └──────┬───────┘
       │                │                │                │
       │ ┌──────────────▼────────────────▼────────────────▼──┐
       │ │         Claude 3.5 Sonnet (Bedrock)                │
       │ │         anthropic.claude-3-5-sonnet-v2             │
       │ └────────────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────────────────────┐
│              Bedrock Knowledge Base (Optional)                │
│  ┌────────────┐    ┌──────────────┐    ┌─────────────────┐  │
│  │ S3 Bucket  │───▶│   Embeddings │───▶│  OpenSearch     │  │
│  │ (Docs)     │    │ (Titan G1)   │    │  Serverless     │  │
│  └────────────┘    └──────────────┘    └─────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

## Agent Workflow

### Sequential Processing

```
1. Knowledge Agent (with RAG)
   ├─ Query: User profile parameters
   ├─ Retrieve: Bedrock KB → Sustainability facts
   ├─ Process: Claude 3.5 Sonnet
   └─ Output: Relevant sustainability information
              │
              ▼
2. Carbon Footprint Agent
   ├─ Input: Knowledge context + User profile
   ├─ Calculate: Emissions by category
   ├─ Process: Claude 3.5 Sonnet
   └─ Output: Carbon footprint breakdown
              │
              ▼
3. Habit Planning Agent
   ├─ Input: Carbon analysis + User goals
   ├─ Design: 7-day sustainable routine
   ├─ Process: Claude 3.5 Sonnet
   └─ Output: Weekly habit plan
              │
              ▼
4. Recommendation Agent
   ├─ Input: All previous outputs
   ├─ Prioritize: High-impact changes
   ├─ Process: Claude 3.5 Sonnet
   └─ Output: Top 5 recommendations
              │
              ▼
         Final Plan
```

## Component Details

### 1. Bedrock Runtime Client

```python
bedrock_runtime = boto3.client('bedrock-runtime')
```

**Purpose**: Invoke Claude 3.5 Sonnet for agent reasoning

**API Call**:
```python
response = bedrock_runtime.invoke_model(
    modelId='anthropic.claude-3-5-sonnet-20241022-v2:0',
    body=json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1000,
        "messages": [{"role": "user", "content": prompt}]
    })
)
```

### 2. Bedrock Agent Runtime Client

```python
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime')
```

**Purpose**: Query Knowledge Base for RAG

**API Call**:
```python
response = bedrock_agent_runtime.retrieve(
    knowledgeBaseId=KNOWLEDGE_BASE_ID,
    retrievalQuery={'text': query},
    retrievalConfiguration={
        'vectorSearchConfiguration': {'numberOfResults': 5}
    }
)
```

### 3. Knowledge Base Setup

**Components**:
- **S3 Bucket**: Stores `sustainability_guide.txt`
- **Embeddings**: Titan Embeddings G1 - Text
- **Vector Store**: OpenSearch Serverless
- **Sync**: Automatic on data changes

**Creation Flow**:
1. Upload documents to S3
2. Create KB in Bedrock console
3. Configure data source (S3)
4. Select embedding model
5. Create/select vector store
6. Sync data source
7. Get Knowledge Base ID

## Data Flow

### Input
```json
{
  "transportation": "gasoline car, 20 km daily commute",
  "diet": "meat-eating, occasional fast food",
  "energy_usage": "standard home, no solar, AC usage high",
  "goals": "reduce carbon footprint by 30% in 6 months"
}
```

### Agent 1 Output (Knowledge)
```
Transportation emissions: 0.19 kg CO2/km for gasoline cars
Diet emissions: 2.5 tons CO2/year for meat-eating
Energy: Standard home ~5 tons CO2/year
```

### Agent 2 Output (Carbon Analysis)
```
Transportation: 1.4 tons CO2/year (20km × 250 days × 0.19kg)
Diet: 2.5 tons CO2/year
Energy: 5.0 tons CO2/year
Total: 8.9 tons CO2/year (below 10-20 ton average)
```

### Agent 3 Output (Habits)
```
Monday: Walk/bike for trips under 5km
Tuesday: Meatless Monday meals
Wednesday: Unplug devices when not in use
...
```

### Agent 4 Output (Recommendations)
```
1. Switch to electric vehicle - Save 1.2 tons CO2/year
2. Reduce meat consumption 50% - Save 1.0 tons CO2/year
3. Install smart thermostat - Save 0.5 tons CO2/year
...
```

## Comparison: CrewAI vs Bedrock

| Aspect | CrewAI | Bedrock |
|--------|--------|---------|
| **Framework** | CrewAI orchestration | Custom sequential |
| **LLM** | OpenAI GPT-4 | Claude 3.5 Sonnet |
| **RAG** | DirectoryReadTool + FileReadTool | Knowledge Bases + S3 |
| **Agent Definition** | Agent class with tools | Function with API calls |
| **Task Management** | Task class with context | Manual context passing |
| **Execution** | crew.kickoff() | Sequential function calls |
| **Deployment** | Local Python | AWS cloud-native |
| **Scaling** | Single process | Serverless auto-scale |
| **Cost** | OpenAI API fees | Bedrock usage fees |
| **Latency** | ~30-60s | ~20-40s |

## Migration Path

### Phase 1: Direct Translation (Current)
- Replace OpenAI with Bedrock Runtime
- Replace file tools with KB queries
- Maintain sequential logic

### Phase 2: Bedrock Agents (Future)
- Create Bedrock Agent with action groups
- Define Lambda functions for calculations
- Use agent orchestration features
- Add guardrails and prompt templates

### Phase 3: Production (Future)
- Deploy as API Gateway + Lambda
- Add DynamoDB for user profiles
- Implement caching layer
- Add monitoring with CloudWatch

## Security Considerations

1. **IAM Permissions**: Least privilege for Bedrock access
2. **Credentials**: Use IAM roles, not access keys
3. **Data Privacy**: S3 bucket encryption
4. **API Keys**: Never commit to version control
5. **Knowledge Base**: Restrict access to authorized users

## Performance Optimization

1. **Caching**: Store KB results for common queries
2. **Parallel Execution**: Run independent agents concurrently
3. **Token Limits**: Optimize prompts to reduce costs
4. **Batch Processing**: Process multiple users together
5. **Regional Deployment**: Use closest Bedrock region

## Cost Estimation

**Per Execution**:
- Agent 1: ~2K tokens = $0.01
- Agent 2: ~2K tokens = $0.01
- Agent 3: ~2K tokens = $0.01
- Agent 4: ~2K tokens = $0.01
- KB Query: ~$0.001
- **Total**: ~$0.05 per plan

**Monthly (1000 users)**:
- Bedrock: ~$50
- Knowledge Base: ~$100 (OpenSearch)
- S3: ~$1
- **Total**: ~$151/month

## Next Steps

1. ✅ Run notebook to validate workflow
2. ⬜ Set up Knowledge Base for RAG
3. ⬜ Test with various user profiles
4. ⬜ Optimize prompts for accuracy
5. ⬜ Deploy as Lambda function
6. ⬜ Add API Gateway frontend
7. ⬜ Implement user authentication
8. ⬜ Add monitoring and logging
