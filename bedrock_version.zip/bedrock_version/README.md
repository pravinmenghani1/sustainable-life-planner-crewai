# Sustainable Life Planner - Amazon Bedrock Version

This is the Amazon Bedrock implementation of the Sustainable Life Planner, using:
- **Amazon Bedrock Runtime** for Claude 3.5 Sonnet
- **Bedrock Knowledge Bases** for RAG
- **Sequential agent orchestration** (similar to CrewAI)

## Quick Start

### 1. Prerequisites

- AWS Account with Bedrock access
- Claude 3.5 Sonnet model enabled in your region
- Python 3.9+

### 2. Setup

```bash
cd bedrock_version

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure AWS credentials
cp .env.example .env
# Edit .env with your AWS credentials
```

### 3. Run the Notebook

```bash
jupyter notebook sustainable_planner_bedrock.ipynb
```

Or use VS Code with Jupyter extension.

## Architecture

### Agent Flow
```
User Profile → Agent 1 (Knowledge + RAG) → Agent 2 (Carbon Calc) 
→ Agent 3 (Habits) → Agent 4 (Recommendations) → Final Plan
```

### Components

1. **Knowledge Agent**: Queries Bedrock Knowledge Base for sustainability data
2. **Carbon Agent**: Calculates emissions using Claude 3.5 Sonnet
3. **Habit Agent**: Creates weekly sustainable routines
4. **Recommendation Agent**: Generates personalized eco-friendly suggestions

## Setting Up Knowledge Base (Optional)

The notebook includes a cell to:
1. Create S3 bucket
2. Upload `sustainability_guide.txt`
3. Instructions for creating Bedrock Knowledge Base

Without KB, the system uses Claude's built-in knowledge.

## Key Differences from CrewAI Version

| Feature | CrewAI | Bedrock |
|---------|--------|---------|
| LLM | OpenAI GPT-4 | Claude 3.5 Sonnet |
| RAG | File tools | Knowledge Bases |
| Orchestration | CrewAI framework | Custom sequential |
| Deployment | Local only | AWS cloud-native |
| Scaling | Single machine | Serverless |

## Cost Considerations

- **Claude 3.5 Sonnet**: ~$3 per 1M input tokens, ~$15 per 1M output tokens
- **Knowledge Base**: OpenSearch Serverless + embeddings
- **Typical run**: ~10K tokens = $0.05-0.10

## Next Steps

1. Enable Bedrock model access in AWS Console
2. Run notebook cells sequentially
3. (Optional) Set up Knowledge Base for RAG
4. Customize user profiles and test
5. Deploy as Lambda function or SageMaker endpoint

## Troubleshooting

**Error: "Could not connect to the endpoint URL"**
- Check AWS credentials in `.env`
- Verify region has Bedrock enabled

**Error: "ValidationException: Model not found"**
- Enable Claude 3.5 Sonnet in Bedrock console
- Check model ID matches your region

**Knowledge Base not working**
- Verify KNOWLEDGE_BASE_ID in `.env`
- Ensure KB is synced and active
- Check IAM permissions for Bedrock
